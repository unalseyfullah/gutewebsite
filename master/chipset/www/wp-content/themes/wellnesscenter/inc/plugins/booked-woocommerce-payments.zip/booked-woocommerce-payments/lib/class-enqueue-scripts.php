<?php

class Booked_WC_EnqueueScript {

	protected $prefix;

	protected $plugin_url;

	private function __construct() {
		$this->prefix = BOOKED_WC_PLUGIN_PREFIX;
		$this->plugin_url = BOOKED_WC_PLUGIN_URL;

		add_action('wp_enqueue_scripts', array($this, 'enqueue_front_end_script'));
		add_action('admin_enqueue_scripts', array($this, 'enqueue_back_end_script'));
	}

	public static function enqueue() {
		return new self();
	}

	public function add_js_variables() {
		
		$app_link = '#';
		$profile_page = Booked_WC_Functions::get_login_page_info();
		if ( $profile_page ) {
			$app_link = get_permalink($profile_page->ID);
		} else if ( $appointments_page = Booked_WC_Functions::get_appointments_page_info() ) {
			$app_link = get_permalink($appointments_page->ID);
		}
		
		$redirect_page = Booked_WC_Settings::get_option('redirect_page');
		
		if ($redirect_page == 'cart'):
			$checkout_page_id = Booked_WC_Helper::get_cart_page();
		else:
			$checkout_page_id = Booked_WC_Helper::get_checkout_page();
		endif;
		
		$checkout_page_link = get_permalink($checkout_page_id);

		// Passing some JS variables
		// Localize the script with new data
		$js_variables_array = array(
			'prefix' => BOOKED_WC_PLUGIN_PREFIX,
			'ajaxurl' => admin_url('admin-ajax.php'),
			'app_link' => $app_link,
			'i18n_confirm_appt_edit' => __('Are you sure you want to change the appointment date? By doing it, the appointment status will be set back to pending.', BOOKED_WC_LANGUAGE_PREFIX),
			'i18n_pay' => __('Are you sure you want to add the appointment to cart and go to checkout?', BOOKED_WC_LANGUAGE_PREFIX),
			'i18n_paid' => __('Paid', BOOKED_WC_LANGUAGE_PREFIX),
			'i18n_awaiting_payment' => __('Awaiting Payment', BOOKED_WC_LANGUAGE_PREFIX),
			'checkout_page' => $checkout_page_link
		);
		wp_localize_script('jquery', 'booked_wc_variables', $js_variables_array );
	}

	public function enqueue_front_end_script() {
		// js
		wp_enqueue_script('booked-wc-admin-functions', $this->plugin_url . '/js/frontend-functions.js', array('jquery') );

		// css
		wp_enqueue_style('booked-wc-admin-styles', $this->plugin_url . '/css/frontend-style.css');

		// add js variables
		$this->add_js_variables();
	}

	public function enqueue_back_end_script() {
		// js
		wp_enqueue_script('booked-wc-admin-functions', $this->plugin_url . '/js/admin-functions.js', array('jquery') );

		// css
		wp_enqueue_style('booked-wc-admin-styles', $this->plugin_url . '/css/admin-style.css');

		// add js variables
		$this->add_js_variables();
	}
}