<?php
if ( !is_user_logged_in() ) {
	return;
}

$parameters = array('load', 'date', 'timeslot', 'app_id', 'app_action', 'source');
foreach ($parameters as $parameter_name) {
	if ( !isset($_POST[$parameter_name]) || empty($_POST[$parameter_name]) ) {
		return;
	}
}


$app_id = intval($_POST['app_id']);
$app_action = $_POST['app_action'];
$source = $_POST['source'];

if (
	!$app_id
	|| $app_action!=='edit'
	|| $source!=='booked_wc_extension'
) {
	return;
}

$load = $_POST['load'];
$date = $_POST['date'];

$timeslot = $_POST['timeslot'];
$timeslot_parts = explode('-',$timeslot);

$date_format = get_option('date_format');
$time_format = get_option('time_format');


if ($timeslot_parts[0] == '0000' && $timeslot_parts[1] == '2400') {
	$timeslotText = 'All day';
} else {
	$timeslotText = date_i18n($time_format,strtotime($timeslot_parts[0])) . (!get_option('booked_hide_end_times') ? ' &ndash; '.date_i18n($time_format,strtotime($timeslot_parts[1])) : '');
}

$reached_limit = false;

$input_date = date('Y-m-j', strtotime($date));
$input_timestamp = strtotime($date.' '.$timeslot_parts[0]);
$input_customer_type = 'current';

$current_user = wp_get_current_user();

$appointment_limit = get_option('booked_appointment_limit');
if ($appointment_limit) {
	$upcoming_user_appointments = booked_user_appointments($current_user->ID,true);
	$reached_limit = $upcoming_user_appointments >= $appointment_limit;
}

$user_nickname = get_user_meta($current_user->ID, 'nickname', true);
?>
<div class="booked-form booked-scrollable">
	
	<p class="booked-title-bar"><small><?php echo __('Update Appointment Date', BOOKED_WC_LANGUAGE_PREFIX); ?></small></p>

	<form action="" method="post" id="newAppointmentForm" data-calendar-id="0">

		<input type="hidden" name="date" value="<?php echo $input_date ?>" />
		<input type="hidden" name="timestamp" value="<?php echo $input_timestamp ?>" />
		<input type="hidden" name="timeslot" value="<?php echo $timeslot; ?>" />
		<input type="hidden" name="customer_type" value="<?php echo $input_customer_type ?>" />
		<input type="hidden" name="action" value="add_appt" />

		<input type="hidden" name="user_id" value="<?php echo $current_user->ID ?>" />

		<input type="hidden" name="calendar_id" value="0" />
		<input type="hidden" name="app_id" value="<?php echo $app_id ?>" />
		<input type="hidden" name="app_action" value="<?php echo $app_action ?>" />
		<input type="hidden" name="source" value="<?php echo $source ?>" />

		<?php
		if (!$reached_limit): ?>
			<p><?php echo sprintf(__('You are about to change the appointment date for %s.', BOOKED_WC_LANGUAGE_PREFIX), $user_nickname); ?> <?php _e('Please confirm that you would like to request the following appointment:', BOOKED_WC_LANGUAGE_PREFIX); ?></p>

			<p class="name">
				<b><i class="fa fa-calendar-o"></i>&nbsp;&nbsp;<?php echo date_i18n($date_format, strtotime($date)) ?>&nbsp;&nbsp;&nbsp;&nbsp;</b>
				<b><i class="fa fa-clock-o"></i>&nbsp;&nbsp;<?php echo $timeslotText ?></b>
			</p>

			<input type="hidden" name="user_id" value="<?php echo $current_user->ID; ?>" />

			<div class="spacer"></div>

			<div class="field">
				<?php if (!$reached_limit): ?>
					<input type="submit" id="submit-edit-request-appointment" class="button button-primary" value="<?php _e('Update Appointment Date', BOOKED_WC_LANGUAGE_PREFIX); ?>">
					<button class="cancel button"><?php _e('Cancel', BOOKED_WC_LANGUAGE_PREFIX); ?></button>
				<?php else: ?>
					<button class="cancel button"><?php _e('Okay', BOOKED_WC_LANGUAGE_PREFIX); ?></button>
				<?php endif; ?>
			</div>
		<?php else : ?>
			<p><?php echo sprintf(_n("Sorry, but you've hit the appointment limit. Each user may only book %d appointment at a time.","Sorry, but you've hit the appointment limit. Each user may only book %d appointments at a time.", $appointment_limit, BOOKED_WC_LANGUAGE_PREFIX), $appointment_limit); ?></p>
		<?php endif; ?>
	</form>
</div>

<a href="#" class="close"><i class="fa fa-remove"></i></a>