<?php
if ( !isset($appointment_id) || !is_numeric($appointment_id) ) {
	return;
}

$appointment = Booked_WC_Appointment::get($appointment_id);
$current_time = current_time('timestamp');

// check if the date has been passed
// if so, hide the edit button
if ( $current_time > $appointment->timestamp ) {
	return;
}

if ( !$appointment->calendar ) {
	return;
}

$calendar_link = $appointment->calendar->calendar_link;
if ( !$calendar_link ) {
	return;
}

$calendar_link = add_query_arg(array(
					'app_id' => $appointment_id,
					'app_action' => 'edit',
					'source' => 'booked_wc_extension'
				), $calendar_link);
?>
<a href="<?php echo $calendar_link ?>" data-app-calendar="<?php echo $calendar_link ?>" data-appt-id="<?php echo $appointment_id ?>" class="edit"><?php _e('Change Date', BOOKED_WC_LANGUAGE_PREFIX); ?></a>