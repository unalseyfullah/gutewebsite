<?php
$appt_id = intval($appt_id);
$appointment = Booked_WC_Appointment::get($appt_id);
$post_status = $appointment->post->post_status;
$awaiting_status = BOOKED_WC_PLUGIN_PREFIX . 'awaiting';
?>

<?php if ( !$appointment->order_id ): ?>
	<a href="#" class="delete" <?php echo $calendar_id ? ' data-calendar-id="'.$calendar_id.'"' : '' ?> ><i class="fa fa-remove"></i></a>
<?php endif ?>

<?php if (
	$post_status===$awaiting_status
	&& !$appointment->is_paid
): ?>
	<?php if ( !$appointment->order_id ): // allow approve button only if the appointment has been manually created ?>
		<button data-appt-id="<?php echo $appt_id ?>" class="approve button button-primary"><?php echo __('Approve', BOOKED_WC_LANGUAGE_PREFIX) ?></button>
	<?php endif ?>
	<span class="booked-wc_status-text awaiting">
		<?php
		if ( $appointment->order_id ) {
			if (current_user_can('manage_options')) :
				echo '<a target="_blank" href="' . admin_url('/post.php?post=' . $appointment->order_id . '&action=edit') . '">' . $appointment->payment_status_text . '</a>';
			else :
				echo $appointment->payment_status_text;
			endif;
		} else {
			echo __('Awaiting Payment', BOOKED_WC_LANGUAGE_PREFIX);
		}
		?>
	</span>
<?php elseif ( $post_status==='draft' ): ?>
	<button data-appt-id="<?php echo $appt_id ?>" class="approve button button-primary"><?php echo __('Approve', BOOKED_WC_LANGUAGE_PREFIX) ?></button>
	<?php if ( $appointment->products): ?>
		<span class="booked-wc_status-text paid">
			<?php
			if ( $appointment->order_id && !$appointment->is_paid ) {
				if (current_user_can('manage_options')) :
					echo '<a target="_blank" href="' . admin_url('/post.php?post=' . $appointment->order_id . '&action=edit') . '">' . $appointment->payment_status_text . '</a>';
				else :
					echo $appointment->payment_status_text;
				endif;
			} else {
				echo __('Paid', BOOKED_WC_LANGUAGE_PREFIX);
			}
			?>
		</span>
	<?php endif ?>
<?php else: ?>
	<?php if ( $appointment->products): ?>
		<span class="booked-wc_status-text paid">
			<?php
			if ( $appointment->order_id && !$appointment->is_paid ) {
				if (current_user_can('manage_options')) :
					echo '<a target="_blank" href="' . admin_url('/post.php?post=' . $appointment->order_id . '&action=edit') . '">' . $appointment->payment_status_text . '</a>';
				else :
					echo $appointment->payment_status_text;
				endif;
			} else {
				echo __('Paid', BOOKED_WC_LANGUAGE_PREFIX);
			}
			?>
		</span>
	<?php endif ?>
<?php endif ?>